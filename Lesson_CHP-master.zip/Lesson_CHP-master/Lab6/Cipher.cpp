#include "Cipher.h"
Cipher::~Cipher() {}